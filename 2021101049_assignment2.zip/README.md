# WordVectorization
A neural word vectorization pipeline built as a part of the assignment for the course CS7.401 at IIIT Hyderabad.

# Pre-Trained Models
https://iiitaphyd-my.sharepoint.com/:f:/g/personal/hardik_sharma_students_iiit_ac_in/Eie8jWNHB6hNktRVEcrzpnkBe_qdszUfqTD9kug_qE_dIA?e=pVc23x

# Pre-trained Emebeddings and Corpus
https://iiitaphyd-my.sharepoint.com/:f:/g/personal/hardik_sharma_students_iiit_ac_in/EhXJGdBbZK9Eqm-yiN7fxCwBMKuwxu9bb_POxBCF0CDnZQ?e=t4oUdz
